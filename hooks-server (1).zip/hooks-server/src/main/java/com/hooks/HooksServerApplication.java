package com.hooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HooksServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HooksServerApplication.class, args);
	}

}
