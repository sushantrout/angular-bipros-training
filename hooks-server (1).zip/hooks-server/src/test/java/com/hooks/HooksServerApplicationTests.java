package com.hooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HooksServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
